import { useNavigate } from "react-router-dom";
import Layout from "./Layout";

export default function About() {
  const navigate = useNavigate();

  return (
    <Layout>
      <div style={{ display: "flex", flexDirection: "column", gap: "40px", paddingBottom: "40px" }}>
        
        {/* HERO SECTION - WITH BACKGROUND IMAGE */}
        <div style={{ 
          position: "relative",
          borderRadius: "24px", 
          overflow: "hidden",
          minHeight: "400px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          padding: "60px 40px",
          backgroundImage: `url('https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          boxShadow: "0 20px 25px -5px rgba(6, 78, 59, 0.3)"
        }}>
          {/* DARK OVERLAY FOR READABILITY */}
          <div style={{
            position: "absolute",
            top: 0, left: 0, right: 0, bottom: 0,
            background: "linear-gradient(to top, rgba(6, 78, 59, 0.9), rgba(6, 78, 59, 0.4))"
          }} />

          {/* TEXT CONTENT */}
          <div style={{ position: "relative", zIndex: 1 }}>
            <h1 style={{ margin: "0 0 20px 0", fontSize: "52px", fontWeight: "900", color: "white", lineHeight: "1.1", letterSpacing: "-1px", maxWidth: "800px", textShadow: "0 2px 4px rgba(0,0,0,0.3)" }}>
              EXCELLENCE IN WASTE MANAGEMENT
            </h1>
            <p style={{ margin: "0 auto 30px auto", fontSize: "20px", color: "#e2e8f0", fontWeight: "500", lineHeight: "1.5", maxWidth: "700px", textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}>
              SmartWaste is a premium, community-driven platform connecting citizens, professional collection teams, and city administrators. We don't just collect waste; we build healthier communities.
            </p>
            <button 
              onClick={() => navigate("/contact")}
              style={{ padding: "14px 28px", backgroundColor: "#16a34a", color: "white", border: "none", borderRadius: "30px", fontSize: "16px", fontWeight: "bold", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "10px", boxShadow: "0 4px 6px rgba(0,0,0,0.2)" }}
            >
              Contact Us Today
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </button>
          </div>
        </div>

        {/* THE GLOBAL CRISIS SECTION */}
        <div style={{ backgroundColor: "#0f172a", borderRadius: "24px", padding: "50px", color: "white" }}>
          <h2 style={{ textAlign: "center", fontSize: "32px", fontWeight: "900", marginBottom: "10px", color: "#4ade80" }}>The Global Crisis We Are Solving</h2>
          <p style={{ textAlign: "center", fontSize: "16px", color: "#94a3b8", marginBottom: "40px" }}>Waste management is not just a city issue; it is a global emergency.</p>
          
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "30px", marginBottom: "40px" }}>
            <div style={{ borderLeft: "4px solid #4ade80", paddingLeft: "20px" }}>
              <h3 style={{ margin: "0 0 10px 0", fontSize: "36px", fontWeight: "900", color: "white" }}>2.01B</h3>
              <p style={{ margin: 0, color: "#cbd5e1", fontSize: "15px", lineHeight: "1.5" }}>Tonnes of municipal solid waste generated globally in a single year, projected to hit 3.4 billion by 2050.</p>
            </div>
            <div style={{ borderLeft: "4px solid #4ade80", paddingLeft: "20px" }}>
              <h3 style={{ margin: "0 0 10px 0", fontSize: "36px", fontWeight: "900", color: "white" }}>Public Health</h3>
              <p style={{ margin: 0, color: "#cbd5e1", fontSize: "15px", lineHeight: "1.5" }}>The WHO warns that uncollected waste releases hazardous chemicals and creates breeding grounds for disease.</p>
            </div>
            <div style={{ borderLeft: "4px solid #4ade80", paddingLeft: "20px" }}>
              <h3 style={{ margin: "0 0 10px 0", fontSize: "36px", fontWeight: "900", color: "white" }}>100+ Years</h3>
              <p style={{ margin: 0, color: "#cbd5e1", fontSize: "15px", lineHeight: "1.5" }}>How long buoyant plastics will continue to pollute our oceans, even if we stopped all pollution today.</p>
            </div>
          </div>

          {/* CITATIONS */}
          <div style={{ borderTop: "1px solid #334155", paddingTop: "20px", fontSize: "11px", color: "#64748b", lineHeight: "1.6" }}>
            <p style={{ margin: "0 0 5px 0" }}><strong>Sources:</strong></p>
            <p style={{ margin: "0 0 3px 0" }}>World Bank Group. (2018). <em>What a Waste 2.0: A Global Snapshot of Solid Waste Management to 2050</em>.</p>
            <p style={{ margin: "0 0 3px 0" }}>World Health Organization. (2025). <em>Throwing away our health: the impacts of solid waste on human health</em>.</p>
            <p style={{ margin: 0 }}>Wu, N., et al. (2025). <em>Coupling fragmentation to a size-selective sedimentation model...</em> Philosophical Transactions A.</p>
          </div>
        </div>

        {/* IMPACT STATISTICS */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", textAlign: "center", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <h2 style={{ margin: "0 0 10px 0", fontSize: "42px", fontWeight: "900", color: "#16a34a" }}>10,000+</h2>
            <p style={{ margin: 0, fontSize: "16px", fontWeight: "700", color: "#0f172a" }}>Tons Collected</p>
          </div>
          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", textAlign: "center", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <h2 style={{ margin: "0 0 10px 0", fontSize: "42px", fontWeight: "900", color: "#16a34a" }}>99.8%</h2>
            <p style={{ margin: 0, fontSize: "16px", fontWeight: "700", color: "#0f172a" }}>On-Time Resolution</p>
          </div>
          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", textAlign: "center", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <h2 style={{ margin: "0 0 10px 0", fontSize: "42px", fontWeight: "900", color: "#16a34a" }}>50+</h2>
            <p style={{ margin: 0, fontSize: "16px", fontWeight: "700", color: "#0f172a" }}>Professional Teams</p>
          </div>
        </div>

        {/* VISION & VALUES */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "30px" }}>
          
          <div style={{ backgroundColor: "white", padding: "40px", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", borderTop: "4px solid #16a34a" }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "28px", color: "#064e3b", fontWeight: "800" }}>Our Vision</h2>
            <p style={{ margin: 0, color: "#475569", fontSize: "16px", lineHeight: "1.8" }}>
              We envision a future where waste is managed seamlessly through technology. A city where every neighborhood is clean, safe, and healthy, and where responsible disposal is a habit shared by everyone.
            </p>
          </div>

          <div style={{ backgroundColor: "white", padding: "40px", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", borderTop: "4px solid #16a34a" }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "28px", color: "#064e3b", fontWeight: "800" }}>Core Values</h2>
            <ul style={{ margin: 0, padding: "0 0 0 20px", color: "#475569", fontSize: "16px", lineHeight: "1.8" }}>
              <li><strong>Excellence:</strong> We do not just collect waste; we do it professionally and on time, every time.</li>
              <li><strong>Transparency:</strong> Our real-time data is open to the public to build trust and accountability.</li>
              <li><strong>Sustainability:</strong> We promote recycling and responsible disposal habits to protect our planet.</li>
            </ul>
          </div>

        </div>

        {/* WHY TRUST US (PREMIUM HOME COLLECTION) */}
        <div style={{ backgroundColor: "#f8fafc", borderRadius: "24px", padding: "50px", border: "1px solid #e2e8f0", display: "flex", gap: "40px", alignItems: "center" }}>
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "32px", color: "#064e3b", fontWeight: "900" }}>Why High-Status Clients Trust Us</h2>
            <p style={{ margin: "0 0 20px 0", color: "#475569", fontSize: "16px", lineHeight: "1.6" }}>
              For homeowners, estates, and businesses, we offer a premium, discreet home collection service. Our verified teams arrive exactly when scheduled, handle all waste types safely, and leave your property spotless.
            </p>
            <ul style={{ margin: 0, padding: "0 0 0 20px", color: "#475569", fontSize: "16px", lineHeight: "1.8", fontWeight: "600" }}>
              <li>Background-checked, uniformed professionals.</li>
              <li>Real-time tracking of the collection vehicle.</li>
              <li>Guaranteed 24-hour response for urgent home pickups.</li>
            </ul>
          </div>
          <div style={{ flex: 1, backgroundColor: "#dcfce7", padding: "30px", borderRadius: "16px", textAlign: "center" }}>
             <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#166534" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
             <h3 style={{ margin: "15px 0 5px 0", fontSize: "20px", color: "#064e3b" }}>Book Home Collection</h3>
             <p style={{ margin: "0 0 15px 0", fontSize: "14px", color: "#166534" }}>Contact us to set up your premium schedule.</p>
             <button onClick={() => navigate("/contact")} style={{ padding: "10px 20px", backgroundColor: "#16a34a", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold" }}>Contact Us</button>
          </div>
        </div>

        {/* TESTIMONIALS */}
        <div>
          <h2 style={{ textAlign: "center", fontSize: "32px", color: "#064e3b", fontWeight: "900", marginBottom: "30px" }}>What People Are Saying</h2>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
            <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
              <p style={{ margin: "0 0 20px 0", fontSize: "16px", color: "#475569", fontStyle: "italic", lineHeight: "1.6" }}>"SmartWaste has completely transformed our estate. The real-time tracking means we know exactly when the team is coming. A truly professional service."</p>
              <p style={{ margin: 0, fontWeight: "800", color: "#0f172a" }}>- Sarah Namubiru, Estate Manager</p>
            </div>
            <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
              <p style={{ margin: "0 0 20px 0", fontSize: "16px", color: "#475569", fontStyle: "italic", lineHeight: "1.6" }}>"The anonymous reporting feature has made a massive difference. Residents can report illegal dumping without fear, and the city resolves it within hours."</p>
              <p style={{ margin: 0, fontWeight: "800", color: "#0f172a" }}>- City Council Official</p>
            </div>
          </div>
        </div>

      </div>
    </Layout>
  );
}