import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import Layout from "./Layout";

export default function Dashboard() {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [points, setPoints] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) { navigate("/"); return; }

    Promise.all([
      fetch("http://localhost:5000/api/reports", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/points", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/teams", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json())
    ]).then(([reportsData, pointsData, teamsData]) => {
      setReports(Array.isArray(reportsData) ? reportsData : []);
      setPoints(Array.isArray(pointsData) ? pointsData : []);
      setTeams(Array.isArray(teamsData) ? teamsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [navigate]);

  if (loading) return <Layout><p style={{ padding: "20px" }}>Loading dashboard data...</p></Layout>;

  const totalPoints = points.length;
  const activeReports = reports.filter(r => r.status !== "Resolved").length;
  const resolvedReports = reports.filter(r => r.status === "Resolved").length;
  const activeTeams = teams.filter(t => t.team_status === "Active").length;

  const priorityData = [
    { name: "High", value: reports.filter(r => r.priority === "High").length },
    { name: "Medium", value: reports.filter(r => r.priority === "Medium").length },
    { name: "Low", value: reports.filter(r => r.priority === "Low").length },
  ];
  const COLORS = ["#ef4444", "#f59e0b", "#22c55e"];

  const districtCounts = {};
  reports.forEach(report => {
    const point = points.find(p => p._id === report.point_id);
    if (point) districtCounts[point.district] = (districtCounts[point.district] || 0) + 1;
  });
  const districtData = Object.keys(districtCounts).map(district => ({
    district, reports: districtCounts[district]
  }));

  // --- STYLES ---
  const backgroundStyle = {
    backgroundColor: "#f8fafc",
    backgroundImage: `
      linear-gradient(to right, rgba(203, 213, 225, 0.4) 1px, transparent 1px),
      linear-gradient(to bottom, rgba(203, 213, 225, 0.4) 1px, transparent 1px),
      radial-gradient(circle at 15% 20%, rgba(59, 130, 246, 0.08), transparent 25%),
      radial-gradient(circle at 85% 80%, rgba(34, 197, 94, 0.06), transparent 25%)
    `,
    backgroundSize: "40px 40px, 40px 40px, 100% 100%, 100% 100%",
    backgroundAttachment: "fixed",
    minHeight: "100vh",
    padding: "0"
  };

  const cardBaseStyle = {
    display: "block",
    padding: "20px",
    background: "linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)",
    borderRadius: "16px",
    border: "1px solid #e2e8f0",
    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -2px rgba(0, 0, 0, 0.02)",
    transition: "transform 0.2s, boxShadow 0.2s",
    cursor: "pointer",
    textDecoration: "none",
    color: "inherit"
  };

  const chartCardStyle = {
    ...cardBaseStyle,
    padding: "25px",
    cursor: "pointer",
  };

  const handleCardHover = (e, isEnter) => {
    if (isEnter) {
      e.currentTarget.style.transform = "translateY(-4px)";
      e.currentTarget.style.boxShadow = "0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -4px rgba(0, 0, 0, 0.05)";
    } else {
      e.currentTarget.style.transform = "translateY(0)";
      e.currentTarget.style.boxShadow = "0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -2px rgba(0, 0, 0, 0.02)";
    }
  };

  return (
    <Layout>
      <div style={backgroundStyle}>
        
        {/* WELCOME HEADER WITH IMAGE BACKGROUND */}
        <div style={{
          marginBottom: "30px",
          borderRadius: "16px",
          overflow: "hidden",
          position: "relative",
          backgroundImage: `url('https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          minHeight: "180px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-end",
          padding: "30px",
          boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)"
        }}>
          <div style={{
            position: "absolute",
            top: 0, left: 0, right: 0, bottom: 0,
            background: "linear-gradient(to top, rgba(15, 23, 42, 0.85), rgba(15, 23, 42, 0.1))"
          }} />
          <div style={{ position: "relative", zIndex: 1, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <h1 style={{ margin: "0 0 8px 0", fontSize: "28px", color: "#ffffff", fontWeight: "800", letterSpacing: "-0.5px" }}>Operations Center</h1>
              <p style={{ margin: 0, fontSize: "16px", color: "#e2e8f0" }}>Welcome back. Here is what is happening in the city today.</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <span style={{ display: "inline-block", padding: "8px 16px", backgroundColor: "#dcfce7", color: "#166534", borderRadius: "20px", fontSize: "13px", fontWeight: "700", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" }}>
                System Online
              </span>
            </div>
          </div>
        </div>

        {/* KPI CARDS - INTERACTIVE */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "20px", marginBottom: "30px" }}>
          <Link to="/points" style={cardBaseStyle} onMouseEnter={(e) => handleCardHover(e, true)} onMouseLeave={(e) => handleCardHover(e, false)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Total Points</span>
              <div style={{ backgroundColor: "#eff6ff", padding: "8px", borderRadius: "8px" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
              </div>
            </div>
            <h2 style={{ margin: 0, fontSize: "32px", color: "#0f172a", fontWeight: "800" }}>{totalPoints}</h2>
          </Link>

          <Link to="/reports" style={cardBaseStyle} onMouseEnter={(e) => handleCardHover(e, true)} onMouseLeave={(e) => handleCardHover(e, false)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Active Reports</span>
              <div style={{ backgroundColor: "#fef2f2", padding: "8px", borderRadius: "8px" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
              </div>
            </div>
            <h2 style={{ margin: 0, fontSize: "32px", color: "#0f172a", fontWeight: "800" }}>{activeReports}</h2>
          </Link>

          <Link to="/reports" style={cardBaseStyle} onMouseEnter={(e) => handleCardHover(e, true)} onMouseLeave={(e) => handleCardHover(e, false)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Resolved</span>
              <div style={{ backgroundColor: "#dcfce7", padding: "8px", borderRadius: "8px" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
              </div>
            </div>
            <h2 style={{ margin: 0, fontSize: "32px", color: "#0f172a", fontWeight: "800" }}>{resolvedReports}</h2>
          </Link>

          <Link to="/teams" style={cardBaseStyle} onMouseEnter={(e) => handleCardHover(e, true)} onMouseLeave={(e) => handleCardHover(e, false)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px" }}>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Active Teams</span>
              <div style={{ backgroundColor: "#f5f3ff", padding: "8px", borderRadius: "8px" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
              </div>
            </div>
            <h2 style={{ margin: 0, fontSize: "32px", color: "#0f172a", fontWeight: "800" }}>{activeTeams}</h2>
          </Link>
        </div>

        {/* CHARTS SECTION - NOW INTERACTIVE */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "30px" }}>
          
          {/* Priority Chart Card */}
          <div 
            style={chartCardStyle} 
            onMouseEnter={(e) => handleCardHover(e, true)} 
            onMouseLeave={(e) => handleCardHover(e, false)}
            onClick={() => navigate("/reports")}
          >
            <h3 style={{ margin: "0 0 15px 0", color: "#0f172a", fontSize: "16px", fontWeight: "700" }}>Reports by Priority</h3>
            <div style={{ height: "220px" }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={priorityData} cx="50%" cy="50%" innerRadius={60} outerRadius={85} paddingAngle={5} dataKey="value" stroke="none">
                    {priorityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div style={{ display: "flex", justifyContent: "center", gap: "20px", marginTop: "10px" }}>
              {priorityData.map((entry, index) => (
                <div key={entry.name} style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "13px", color: "#64748b", fontWeight: "600" }}>
                  <div style={{ width: "10px", height: "10px", borderRadius: "50%", backgroundColor: COLORS[index] }}></div>
                  {entry.name} ({entry.value})
                </div>
              ))}
            </div>
          </div>

          {/* District Chart Card */}
          <div 
            style={chartCardStyle} 
            onMouseEnter={(e) => handleCardHover(e, true)} 
            onMouseLeave={(e) => handleCardHover(e, false)}
            onClick={() => navigate("/reports")}
          >
            <h3 style={{ margin: "0 0 15px 0", color: "#0f172a", fontSize: "16px", fontWeight: "700" }}>Reports by District</h3>
            <div style={{ height: "220px" }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={districtData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorBar" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.9}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.2}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="district" tick={{ fontSize: 12, fill: "#64748b" }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: "#64748b" }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: "#f8fafc" }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }} />
                  <Bar dataKey="reports" fill="url(#colorBar)" radius={[6, 6, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* RECENT REPORTS TABLE */}
        <div style={{ backgroundColor: "white", borderRadius: "16px", border: "1px solid #e2e8f0", boxShadow: "0 2px 4px rgba(0,0,0,0.02)", overflow: "hidden" }}>
          <div style={{ padding: "20px 25px", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h3 style={{ margin: 0, color: "#0f172a", fontSize: "16px", fontWeight: "700" }}>Recent Waste Reports</h3>
            <Link to="/reports" style={{ fontSize: "13px", color: "#3b82f6", fontWeight: "700", textDecoration: "none", padding: "8px 16px", backgroundColor: "#eff6ff", borderRadius: "8px" }}>View All Reports</Link>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ backgroundColor: "#f8fafc" }}>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>ID</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Issue Type</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Priority</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {reports.slice(0, 5).map((report) => (
                <tr key={report._id} style={{ borderBottom: "1px solid #f1f5f9", transition: "background-color 0.2s" }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8fafc"} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}>
                  <td style={{ padding: "14px 25px", color: "#64748b", fontWeight: "600", fontSize: "13px" }}>{report._id}</td>
                  <td style={{ padding: "14px 25px", color: "#1e293b", fontWeight: "600", fontSize: "13px" }}>{report.issue_type}</td>
                  <td style={{ padding: "14px 25px" }}>
                    <span style={{ 
                      padding: "4px 10px", borderRadius: "20px", fontSize: "11px", fontWeight: "700", 
                      backgroundColor: report.priority === "High" ? "#fee2e2" : report.priority === "Medium" ? "#fef3c7" : "#dcfce7", 
                      color: report.priority === "High" ? "#991b1b" : report.priority === "Medium" ? "#92400e" : "#166534" 
                    }}>
                      {report.priority}
                    </span>
                  </td>
                  <td style={{ padding: "14px 25px", color: "#64748b", fontSize: "13px", fontWeight: "500" }}>{report.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
}