import { useState, useEffect } from "react";
import Layout from "./Layout";

export default function Schedules() {
  const [schedules, setSchedules] = useState([]);
  const [points, setPoints] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);

  const [contextMenu, setContextMenu] = useState(null);
  const [selectedSchedule, setSelectedSchedule] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    Promise.all([
      fetch("http://localhost:5000/api/schedules", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/points", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/teams", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json())
    ]).then(([schedulesData, pointsData, teamsData]) => {
      setSchedules(Array.isArray(schedulesData) ? schedulesData : []);
      setPoints(Array.isArray(pointsData) ? pointsData : []);
      setTeams(Array.isArray(teamsData) ? teamsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));

    const handleClick = () => setContextMenu(null);
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);

  const handleContextMenu = (e, schedule) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.pageX, y: e.pageY, schedule });
  };

  if (loading) return <Layout><p>Loading...</p></Layout>;

  return (
    <Layout>
      <div onContextMenu={(e) => e.preventDefault()}>
        <div style={{ backgroundColor: "white", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", overflow: "hidden" }}>
          <div style={{ padding: "20px 25px", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h2 style={{ margin: 0, color: "#0f172a", fontSize: "18px", fontWeight: "700" }}>Collection Schedules</h2>
              <p style={{ margin: "4px 0 0 0", fontSize: "13px", color: "#64748b" }}>Right-click a schedule to view details.</p>
            </div>
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ backgroundColor: "#f8fafc" }}>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>ID</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Point</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Team</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Date</th>
                <th style={{ padding: "12px 25px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {schedules.map(schedule => {
                const point = points.find(p => p._id === schedule.point_id);
                const team = teams.find(t => t._id === schedule.team_id);
                return (
                  <tr 
                    key={schedule._id} 
                    onContextMenu={(e) => handleContextMenu(e, schedule)}
                    style={{ borderBottom: "1px solid #f1f5f9", cursor: "context-menu", transition: "background-color 0.2s" }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8fafc"}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
                  >
                    <td style={{ padding: "14px 25px", color: "#64748b", fontWeight: "600", fontSize: "13px" }}>{schedule._id}</td>
                    <td style={{ padding: "14px 25px", color: "#1e293b", fontWeight: "600", fontSize: "13px" }}>{point ? point.name : schedule.point_id}</td>
                    <td style={{ padding: "14px 25px", color: "#64748b", fontSize: "13px" }}>{team ? team.team_name : schedule.team_id}</td>
                    <td style={{ padding: "14px 25px", color: "#64748b", fontSize: "13px" }}>{new Date(schedule.scheduled_date).toLocaleDateString()}</td>
                    <td style={{ padding: "14px 25px" }}>
                      <span style={{ padding: "4px 10px", borderRadius: "20px", fontSize: "11px", fontWeight: "700", backgroundColor: schedule.schedule_status === "Confirmed" ? "#dcfce7" : "#fef3c7", color: schedule.schedule_status === "Confirmed" ? "#166534" : "#92400e" }}>
                        {schedule.schedule_status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {contextMenu && (
          <div style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x, backgroundColor: "white", borderRadius: "8px", boxShadow: "0 4px 12px rgba(0,0,0,0.15)", border: "1px solid #e2e8f0", zIndex: 9999, minWidth: "200px", overflow: "hidden" }}>
            <div 
              onClick={() => { setSelectedSchedule(contextMenu.schedule); setContextMenu(null); }}
              style={{ padding: "12px 16px", cursor: "pointer", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f1f5f9"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
            >
              View Full Details
            </div>
          </div>
        )}

        {selectedSchedule && (
          <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 10000 }}>
            <div style={{ backgroundColor: "white", padding: "35px", borderRadius: "12px", width: "450px", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.2)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                <h3 style={{ margin: 0, fontSize: "22px", color: "#0f172a" }}>Schedule Details</h3>
                <button onClick={() => setSelectedSchedule(null)} style={{ background: "none", border: "none", fontSize: "20px", cursor: "pointer", color: "#64748b" }}>X</button>
              </div>
              
              <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Schedule ID</p>
                  <p style={{ margin: 0, fontSize: "16px", color: "#0f172a", fontWeight: "600" }}>{selectedSchedule._id}</p>
                </div>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Collection Point</p>
                  <p style={{ margin: 0, fontSize: "15px", color: "#1e293b", fontWeight: "500" }}>
                    {points.find(p => p._id === selectedSchedule.point_id)?.name || selectedSchedule.point_id}
                  </p>
                </div>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Assigned Team</p>
                  <p style={{ margin: 0, fontSize: "15px", color: "#1e293b", fontWeight: "500" }}>
                    {teams.find(t => t._id === selectedSchedule.team_id)?.team_name || selectedSchedule.team_id}
                  </p>
                </div>
                <div style={{ display: "flex", gap: "20px" }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Date</p>
                    <p style={{ margin: 0, fontSize: "15px", color: "#0f172a", fontWeight: "500" }}>{new Date(selectedSchedule.scheduled_date).toLocaleDateString()}</p>
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Time</p>
                    <p style={{ margin: 0, fontSize: "15px", color: "#0f172a", fontWeight: "500" }}>{selectedSchedule.scheduled_time}</p>
                  </div>
                </div>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Status</p>
                  <span style={{ padding: "4px 10px", borderRadius: "20px", fontSize: "12px", fontWeight: "700", backgroundColor: selectedSchedule.schedule_status === "Confirmed" ? "#dcfce7" : "#fef3c7", color: selectedSchedule.schedule_status === "Confirmed" ? "#166534" : "#92400e" }}>
                    {selectedSchedule.schedule_status}
                  </span>
                </div>
              </div>

              <button onClick={() => setSelectedSchedule(null)} style={{ width: "100%", marginTop: "25px", padding: "12px", backgroundColor: "#0f172a", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", fontSize: "14px" }}>Close</button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}