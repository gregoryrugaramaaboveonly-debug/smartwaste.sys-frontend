import { useState, useEffect } from "react";
import Layout from "./Layout";
import toast from "react-hot-toast";

export default function Teams() {
  const [teams, setTeams] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState(""); 
  
  const [formData, setFormData] = useState({ team_name: "", service_provider: "", contact_number: "", operating_district: "", vehicle_registration: "SAMPLE-00", team_status: "Active" });

  const token = localStorage.getItem("token");
  const isAdmin = localStorage.getItem("role") === "admin";

  const fetchData = () => {
    Promise.all([
      fetch("http://localhost:5000/api/teams", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/reports", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json())
    ]).then(([teamsData, reportsData]) => {
      setTeams(Array.isArray(teamsData) ? teamsData : []);
      setReports(Array.isArray(reportsData) ? reportsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  const handleAddTeam = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/teams", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        setShowForm(false);
        setFormData({ team_name: "", service_provider: "", contact_number: "", operating_district: "", vehicle_registration: "SAMPLE-00", team_status: "Active" });
        toast.success("Team added successfully");
        fetchData();
      }
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this team?")) {
      await fetch(`http://localhost:5000/api/teams/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
      toast.success("Team deleted");
      fetchData();
    }
  };

  if (loading) return <Layout><p>Loading...</p></Layout>;

  const filteredTeams = teams.filter(team => 
    team.team_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    team.operating_district.toLowerCase().includes(searchTerm.toLowerCase()) ||
    team._id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      {isAdmin && (
        <div style={{ marginBottom: "20px" }}>
          <button onClick={() => setShowForm(!showForm)} style={{ padding: "10px 20px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "600", fontSize: "14px" }}>
            {showForm ? "Cancel" : "+ Add New Team"}
          </button>
          {showForm && (
            <form onSubmit={handleAddTeam} style={{ marginTop: "15px", backgroundColor: "white", padding: "20px", borderRadius: "12px", boxShadow: "0 2px 4px rgba(0,0,0,0.04)", display: "flex", gap: "10px", flexWrap: "wrap", border: "1px solid #e2e8f0" }}>
              <input required placeholder="Team Name" value={formData.team_name} onChange={e => setFormData({...formData, team_name: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required placeholder="Service Provider" value={formData.service_provider} onChange={e => setFormData({...formData, service_provider: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required placeholder="Contact Number" value={formData.contact_number} onChange={e => setFormData({...formData, contact_number: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required placeholder="District" value={formData.operating_district} onChange={e => setFormData({...formData, operating_district: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <button type="submit" style={{ padding: "10px 20px", backgroundColor: "#166534", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>Save Team</button>
            </form>
          )}
        </div>
      )}

      <div style={{ backgroundColor: "white", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", overflow: "hidden", border: "1px solid #e2e8f0" }}>
        
        <div style={{ padding: "20px 25px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ margin: 0, color: "#0f172a", fontSize: "16px", fontWeight: "700" }}>Collection Teams Directory</h2>
          <input type="text" placeholder="Search teams..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", width: "250px", fontSize: "13px" }} />
        </div>

        <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
          <thead>
            <tr style={{ backgroundColor: "#f8fafc" }}>
              <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>ID</th>
              <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Team Name</th>
              <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>District</th>
              <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Status</th>
              <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Active Jobs</th>
              {isAdmin && <th style={{ padding: "12px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase" }}>Action</th>}
            </tr>
          </thead>
          <tbody>
            {filteredTeams.map(team => {
              // Calculate active jobs for this team
              const activeJobs = reports.filter(r => r.assigned_team_id === team._id && r.status === "Assigned").length;

              return (
                <tr key={team._id} style={{ borderBottom: "1px solid #f1f5f9", transition: "background-color 0.2s" }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8fafc"} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}>
                  <td style={{ padding: "14px 25px", color: "#64748b", fontWeight: "600", fontSize: "13px" }}>{team._id}</td>
                  <td style={{ padding: "14px 25px", color: "#1e293b", fontWeight: "600", fontSize: "13px" }}>{team.team_name}</td>
                  <td style={{ padding: "14px 25px", color: "#64748b", fontSize: "13px" }}>{team.operating_district}</td>
                  <td style={{ padding: "14px 25px" }}>
                    <span style={{ padding: "4px 10px", borderRadius: "20px", fontSize: "11px", fontWeight: "700", backgroundColor: team.team_status === "Active" ? "#dcfce7" : "#fef3c7", color: team.team_status === "Active" ? "#166534" : "#92400e" }}>
                      {team.team_status}
                    </span>
                  </td>
                  <td style={{ padding: "14px 25px" }}>
                    <span style={{ fontWeight: "700", color: activeJobs > 0 ? "#dc2626" : "#16a34a", fontSize: "14px" }}>
                      {activeJobs} {activeJobs === 1 ? "job" : "jobs"}
                    </span>
                  </td>
                  {isAdmin && (
                    <td style={{ padding: "14px 25px" }}>
                      <button onClick={() => handleDelete(team._id)} style={{ padding: "6px 12px", backgroundColor: "#dc2626", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", fontSize: "12px" }}>Delete</button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}