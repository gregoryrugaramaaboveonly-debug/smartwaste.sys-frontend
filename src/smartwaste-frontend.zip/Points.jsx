import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import Layout from "./Layout";
import toast from "react-hot-toast";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

export default function Points() {
  const [points, setPoints] = useState([]);
  const [reports, setReports] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState(""); 
  
  const [formData, setFormData] = useState({ name: "", district: "", area: "", waste_type: "Mixed", capacity_kg: 1000, current_status: "Empty", lat: "", lng: "" });
  const [selectedTeams, setSelectedTeams] = useState({});

  const token = localStorage.getItem("token");
  const isAdmin = localStorage.getItem("role") === "admin";

  const fetchData = () => {
    Promise.all([
      fetch("http://localhost:5000/api/points", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/reports", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/teams", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json())
    ]).then(([pointsData, reportsData, teamsData]) => {
      setPoints(Array.isArray(pointsData) ? pointsData : []);
      setReports(Array.isArray(reportsData) ? reportsData : []);
      setTeams(Array.isArray(teamsData) ? teamsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  const handleAddPoint = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/points", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        setShowForm(false);
        setFormData({ name: "", district: "", area: "", waste_type: "Mixed", capacity_kg: 1000, current_status: "Empty", lat: "", lng: "" });
        toast.success("Point added successfully");
        fetchData();
      }
    } catch (err) { console.error(err); }
  };

  const handleQuickAssign = async (reportId) => {
    const teamId = selectedTeams[reportId];
    if (!teamId) return toast.error("Please select a team first");
    try {
      const response = await fetch(`http://localhost:5000/api/reports/${reportId}/assign`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ team_id: teamId })
      });
      if (response.ok) {
        toast.success("Team assigned successfully");
        fetchData();
      }
    } catch (err) { console.error(err); }
  };

  if (loading) return <Layout><p>Loading...</p></Layout>;

  const mapCenter = [0.3476, 32.5825];

  const filteredPoints = points.filter(point => 
    point.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    point.district.toLowerCase().includes(searchTerm.toLowerCase()) ||
    point._id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      {isAdmin && (
        <div style={{ marginBottom: "20px" }}>
          <button onClick={() => setShowForm(!showForm)} style={{ padding: "10px 20px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "600", fontSize: "14px" }}>
            {showForm ? "Cancel" : "+ Add New Collection Point"}
          </button>
          {showForm && (
            <form onSubmit={handleAddPoint} style={{ marginTop: "15px", backgroundColor: "white", padding: "20px", borderRadius: "12px", boxShadow: "0 2px 4px rgba(0,0,0,0.04)", display: "flex", gap: "10px", flexWrap: "wrap", border: "1px solid #e2e8f0" }}>
              <input required placeholder="Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required placeholder="District" value={formData.district} onChange={e => setFormData({...formData, district: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required placeholder="Area" value={formData.area} onChange={e => setFormData({...formData, area: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <select value={formData.waste_type} onChange={e => setFormData({...formData, waste_type: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }}>
                <option value="Mixed">Mixed</option>
                <option value="Organic">Organic</option>
                <option value="Plastics">Plastics</option>
              </select>
              <input required type="number" step="any" placeholder="Latitude" value={formData.lat} onChange={e => setFormData({...formData, lat: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input required type="number" step="any" placeholder="Longitude" value={formData.lng} onChange={e => setFormData({...formData, lng: e.target.value})} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <button type="submit" style={{ padding: "10px 20px", backgroundColor: "#166534", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>Save</button>
            </form>
          )}
        </div>
      )}

      <div style={{ height: "300px", width: "100%", borderRadius: "16px", overflow: "hidden", marginBottom: "25px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", border: "1px solid #e2e8f0" }}>
        <MapContainer center={mapCenter} zoom={11} style={{ height: "100%", width: "100%" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap' />
          {points.map((point) => {
            if (!point.location || !point.location.coordinates) return null;
            const position = [point.location.coordinates[1], point.location.coordinates[0]];
            const pointReports = reports.filter(r => r.point_id === point._id && r.status !== "Resolved");

            return (
              <Marker key={point._id} position={position}>
                <Popup minWidth={300}>
                  <div style={{ fontFamily: "'Segoe UI', sans-serif" }}>
                    <h3 style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#0f172a" }}>{point.name}</h3>
                    <p style={{ margin: "0 0 10px 0", fontSize: "12px", color: "#64748b" }}>Status: {point.current_status}</p>
                    
                    {pointReports.length > 0 ? (
                      <div style={{ borderTop: "1px solid #e2e8f0", paddingTop: "10px" }}>
                        <strong style={{ fontSize: "13px", color: "#dc2626", display: "block", marginBottom: "8px" }}>Active Complaints:</strong>
                        {pointReports.map(r => (
                          <div key={r._id} style={{ backgroundColor: "#f8fafc", padding: "10px", borderRadius: "6px", marginBottom: "8px", border: "1px solid #e2e8f0" }}>
                            <strong style={{ fontSize: "13px", color: "#1e293b" }}>{r.issue_type}</strong>
                            <p style={{ margin: "4px 0", fontSize: "12px", color: "#64748b" }}>{r.description}</p>
                            <p style={{ margin: "0 0 8px 0", fontSize: "11px", color: "#94a3b8" }}>Reported by: {r.reporter_name}</p>
                            
                            <div style={{ display: "flex", gap: "5px" }}>
                              <select 
                                onChange={(e) => setSelectedTeams({ ...selectedTeams, [r._id]: e.target.value })}
                                style={{ flex: 1, padding: "4px", borderRadius: "4px", border: "1px solid #cbd5e1", fontSize: "12px" }}
                              >
                                <option value="">Select Team</option>
                                {teams.map(t => <option key={t._id} value={t._id}>{t.team_name}</option>)}
                              </select>
                              <button 
                                onClick={() => handleQuickAssign(r._id)}
                                style={{ padding: "4px 8px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "4px", cursor: "pointer", fontSize: "12px", fontWeight: "bold" }}
                              >
                                Assign
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p style={{ fontSize: "12px", color: "#166534", backgroundColor: "#dcfce7", padding: "8px", borderRadius: "6px" }}>No active complaints at this location.</p>
                    )}
                    
                    <a href={`https://www.google.com/maps/dir/?api=1&destination=${position[0]},${position[1]}`} target="_blank" rel="noreferrer" style={{ display: "block", textAlign: "center", marginTop: "10px", color: "#3b82f6", fontWeight: "bold", fontSize: "12px", textDecoration: "none" }}>Get Directions</a>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>

      <div style={{ backgroundColor: "white", borderRadius: "16px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", overflow: "hidden", border: "1px solid #e2e8f0" }}>
        <div style={{ padding: "20px 25px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ margin: 0, color: "#0f172a", fontSize: "16px", fontWeight: "700" }}>Collection Points Directory</h2>
          <input type="text" placeholder="Search points..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ padding: "8px 12px", borderRadius: "8px", border: "1px solid #cbd5e1", width: "250px", fontSize: "13px" }} />
        </div>

        <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
          <thead>
            <tr style={{ backgroundColor: "#f8fafc" }}>
              <th style={{ padding: "10px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>ID</th>
              <th style={{ padding: "10px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Name</th>
              <th style={{ padding: "10px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>District</th>
              <th style={{ padding: "10px 25px", borderBottom: "1px solid #f1f5f9", color: "#64748b", fontSize: "11px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredPoints.map(point => (
              <tr key={point._id} style={{ borderBottom: "1px solid #f1f5f9", transition: "background-color 0.2s" }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8fafc"} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}>
                <td style={{ padding: "14px 25px", color: "#64748b", fontWeight: "600", fontSize: "13px" }}>{point._id}</td>
                <td style={{ padding: "14px 25px", color: "#1e293b", fontWeight: "600", fontSize: "13px" }}>{point.name}</td>
                <td style={{ padding: "14px 25px", color: "#64748b", fontSize: "13px" }}>{point.district}</td>
                <td style={{ padding: "14px 25px" }}>
                  <span style={{ padding: "4px 10px", borderRadius: "20px", fontSize: "11px", fontWeight: "700", backgroundColor: point.current_status === "Overflowing" ? "#fee2e2" : "#dcfce7", color: point.current_status === "Overflowing" ? "#991b1b" : "#166534" }}>
                    {point.current_status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}