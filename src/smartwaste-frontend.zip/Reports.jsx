import { useState, useEffect } from "react";
import Layout from "./Layout";
import toast from "react-hot-toast";

export default function Reports() {
  const [reports, setReports] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTeams, setSelectedTeams] = useState({});
  const [searchTerm, setSearchTerm] = useState("");

  const [contextMenu, setContextMenu] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);

  const token = localStorage.getItem("token");
  const isAdmin = localStorage.getItem("role") === "admin";

  const fetchData = () => {
    Promise.all([
      fetch("http://localhost:5000/api/reports", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json()),
      fetch("http://localhost:5000/api/teams", { headers: { Authorization: `Bearer ${token}` } }).then(res => res.json())
    ]).then(([reportsData, teamsData]) => {
      setReports(Array.isArray(reportsData) ? reportsData : []);
      setTeams(Array.isArray(teamsData) ? teamsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
    const handleClick = () => setContextMenu(null);
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);

  const handleAssign = async (reportId) => {
    const teamId = selectedTeams[reportId];
    if (!teamId) return toast.error("Please select a team first");

    try {
      const response = await fetch(`http://localhost:5000/api/reports/${reportId}/assign`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ team_id: teamId })
      });
      if (response.ok) {
        toast.success("Team assigned");
        fetchData();
      }
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (reportId) => {
    if (window.confirm("Are you sure you want to delete this report?")) {
      try {
        const response = await fetch(`http://localhost:5000/api/reports/${reportId}`, {
          method: "DELETE", headers: { Authorization: `Bearer ${token}` }
        });
        if (response.ok) {
          toast.success("Report deleted");
          fetchData();
        }
      } catch (err) { console.error(err); }
    }
  };

  const exportSingleCSV = (report) => {
    const headers = ["ID", "Issue Type", "Description", "Priority", "Status", "Reporter Name", "Anonymous", "Upvotes"];
    const row = [
      report._id,
      `"${(report.issue_type || "").replace(/"/g, '""')}"`,
      `"${(report.description || "").replace(/"/g, '""')}"`,
      report.priority,
      report.status,
      `"${(report.reporter_name || "").replace(/"/g, '""')}"`,
      report.is_anonymous ? "Yes" : "No",
      report.upvotes || 0
    ];

    const csvContent = [headers, row].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Report_${report._id}.csv`;
    link.click();
    setContextMenu(null);
    toast.success("Report downloaded");
  };

  const handleExportAllCSV = () => {
    if (reports.length === 0) return toast.error("No reports to export");
    const headers = ["ID", "Issue Type", "Description", "Priority", "Status", "Reporter Name", "Anonymous", "Upvotes"];
    const rows = reports.map(r => [
      r._id, `"${(r.issue_type || "").replace(/"/g, '""')}"`, `"${(r.description || "").replace(/"/g, '""')}"`, r.priority, r.status, `"${(r.reporter_name || "").replace(/"/g, '""')}"`, r.is_anonymous ? "Yes" : "No", r.upvotes || 0
    ]);
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "SmartWaste_All_Reports.csv";
    link.click();
    toast.success("All reports exported");
  };

  // The crucial fix for the right-click menu
  const handleContextMenu = (e, report) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.pageX, y: e.pageY, report });
  };

  if (loading) return <Layout><p>Loading...</p></Layout>;

  const filteredReports = reports.filter(report => 
    report.issue_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    report._id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    report.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      {/* Prevent the default browser menu on the whole page */}
      <div onContextMenu={(e) => e.preventDefault()}>
        <div style={{ backgroundColor: "white", borderRadius: "10px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", overflow: "hidden" }}>
          
          <div style={{ padding: "15px 20px", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <h2 style={{ margin: 0, color: "#0f172a", fontSize: "18px" }}>All Waste Reports</h2>
              <p style={{ margin: "4px 0 0 0", fontSize: "12px", color: "#64748b" }}>Right-click on a row for more actions.</p>
            </div>
            <div style={{ display: "flex", gap: "10px" }}>
              <input type="text" placeholder="Search reports..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ padding: "8px 12px", borderRadius: "6px", border: "1px solid #cbd5e1", width: "200px", fontSize: "14px" }} />
              <button onClick={handleExportAllCSV} style={{ padding: "8px 16px", backgroundColor: "#166534", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", fontSize: "14px" }}>Export All</button>
            </div>
          </div>

          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ backgroundColor: "#f8fafc" }}>
                <th style={{ padding: "12px 20px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "12px" }}>ID</th>
                <th style={{ padding: "12px 20px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "12px" }}>Issue Type</th>
                <th style={{ padding: "12px 20px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "12px" }}>Priority</th>
                <th style={{ padding: "12px 20px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "12px" }}>Status</th>
                <th style={{ padding: "12px 20px", borderBottom: "1px solid #e2e8f0", color: "#64748b", fontSize: "12px" }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredReports.map(report => (
                <tr 
                  key={report._id} 
                  onContextMenu={(e) => handleContextMenu(e, report)} 
                  style={{ borderBottom: "1px solid #e2e8f0", cursor: "context-menu", transition: "background-color 0.2s" }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f8fafc"}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
                >
                  <td style={{ padding: "12px 20px", color: "#64748b", fontWeight: "bold", fontSize: "14px" }}>{report._id}</td>
                  <td style={{ padding: "12px 20px", color: "#1e293b", fontWeight: "600", fontSize: "14px" }}>{report.issue_type}</td>
                  <td style={{ padding: "12px 20px" }}>
                    <span style={{ padding: "4px 10px", borderRadius: "20px", fontSize: "12px", fontWeight: "bold", backgroundColor: report.priority === "High" ? "#fee2e2" : report.priority === "Medium" ? "#fef3c7" : "#dcfce7", color: report.priority === "High" ? "#991b1b" : report.priority === "Medium" ? "#92400e" : "#166534" }}>
                      {report.priority}
                    </span>
                  </td>
                  <td style={{ padding: "12px 20px", color: "#64748b", fontSize: "14px" }}>{report.status}</td>
                  <td style={{ padding: "12px 20px", display: "flex", gap: "10px", alignItems: "center" }}>
                    {(report.status === "Pending" || report.status === "Assigned") ? (
                      <>
                        <select onChange={(e) => setSelectedTeams({ ...selectedTeams, [report._id]: e.target.value })} defaultValue={report.assigned_team_id || ""} style={{ padding: "6px", borderRadius: "6px", border: "1px solid #cbd5e1", fontSize: "14px" }}>
                          <option value="">Select Team</option>
                          {teams.map(t => <option key={t._id} value={t._id}>{t.team_name}</option>)}
                        </select>
                        <button onClick={() => handleAssign(report._id)} style={{ padding: "6px 12px", backgroundColor: report.status === "Assigned" ? "#f59e0b" : "#3b82f6", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", fontSize: "12px" }}>
                          {report.status === "Assigned" ? "Re-Assign" : "Assign"}
                        </button>
                      </>
                    ) : (
                      <span style={{ color: "#166534", fontWeight: "bold", fontSize: "12px" }}>Resolved</span>
                    )}
                    {isAdmin && (
                      <button onClick={() => handleDelete(report._id)} style={{ padding: "6px 12px", backgroundColor: "#dc2626", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", fontSize: "12px" }}>Delete</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* THE CUSTOM CONTEXT MENU */}
        {contextMenu && (
          <div style={{ position: "fixed", top: contextMenu.y, left: contextMenu.x, backgroundColor: "white", borderRadius: "8px", boxShadow: "0 4px 12px rgba(0,0,0,0.15)", border: "1px solid #e2e8f0", zIndex: 9999, minWidth: "200px", overflow: "hidden" }}>
            <div 
              onClick={() => { setSelectedReport(contextMenu.report); setContextMenu(null); }}
              style={{ padding: "12px 16px", cursor: "pointer", borderBottom: "1px solid #e2e8f0", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f1f5f9"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
            >
              View Full Details
            </div>
            <div 
              onClick={() => exportSingleCSV(contextMenu.report)}
              style={{ padding: "12px 16px", cursor: "pointer", borderBottom: "1px solid #e2e8f0", fontSize: "14px", color: "#0f172a", fontWeight: "600" }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#f1f5f9"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
            >
              Download this Report
            </div>
            <div 
              onClick={() => { handleDelete(contextMenu.report._id); setContextMenu(null); }}
              style={{ padding: "12px 16px", cursor: "pointer", fontSize: "14px", color: "#dc2626", fontWeight: "600" }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = "#fef2f2"}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "white"}
            >
              Delete Report
            </div>
          </div>
        )}

        {/* DETAILS MODAL */}
        {selectedReport && (
          <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 10000 }}>
            <div style={{ backgroundColor: "white", padding: "35px", borderRadius: "12px", width: "500px", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.2)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                <h3 style={{ margin: 0, fontSize: "22px", color: "#0f172a" }}>Report Details</h3>
                <button onClick={() => setSelectedReport(null)} style={{ background: "none", border: "none", fontSize: "20px", cursor: "pointer", color: "#64748b" }}>X</button>
              </div>
              
              <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Report ID</p>
                  <p style={{ margin: 0, fontSize: "16px", color: "#0f172a", fontWeight: "600" }}>{selectedReport._id}</p>
                </div>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Issue Type</p>
                  <p style={{ margin: 0, fontSize: "16px", color: "#0f172a", fontWeight: "600" }}>{selectedReport.issue_type}</p>
                </div>
                <div>
                  <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Description</p>
                  <p style={{ margin: 0, fontSize: "14px", color: "#1e293b", backgroundColor: "#f8fafc", padding: "10px", borderRadius: "6px" }}>{selectedReport.description || "No description provided."}</p>
                </div>
                <div style={{ display: "flex", gap: "20px" }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Reported By (Real Name)</p>
                    <p style={{ margin: 0, fontSize: "15px", color: "#dc2626", fontWeight: "600" }}>{selectedReport.reporter_name}</p>
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Privacy</p>
                    <p style={{ margin: 0, fontSize: "15px", color: selectedReport.is_anonymous ? "#dc2626" : "#166534", fontWeight: "600" }}>
                      {selectedReport.is_anonymous ? "Marked Anonymous" : "Public"}
                    </p>
                  </div>
                </div>
                <div style={{ display: "flex", gap: "20px" }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Upvotes</p>
                    <p style={{ margin: 0, fontSize: "15px", color: "#0f172a", fontWeight: "600" }}>{selectedReport.upvotes || 0}</p>
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>Status</p>
                    <p style={{ margin: 0, fontSize: "15px", color: "#0f172a", fontWeight: "600" }}>{selectedReport.status}</p>
                  </div>
                </div>
              </div>

              <button onClick={() => setSelectedReport(null)} style={{ width: "100%", marginTop: "25px", padding: "12px", backgroundColor: "#0f172a", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", fontSize: "14px" }}>Close</button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}