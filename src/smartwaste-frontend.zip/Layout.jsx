import { Link, useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Layout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passMessage, setPassMessage] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setPassMessage("Updating...");
    const token = localStorage.getItem("token");

    try {
      const response = await fetch("http://localhost:5000/api/auth/change-password", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ oldPassword, newPassword })
      });

      const data = await response.json();
      if (response.ok) {
        setPassMessage("Password updated successfully!");
        setTimeout(() => {
          setShowPasswordModal(false);
          setPassMessage("");
          setOldPassword("");
          setNewPassword("");
        }, 2000);
      } else {
        setPassMessage(data.error);
      }
    } catch (err) {
      setPassMessage("Server error.");
    }
  };

  const styles = {
    appContainer: { display: "flex", height: "100vh", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif", backgroundColor: "#f4fdf8", overflow: "hidden" },
    sidebar: { 
      width: isSidebarOpen ? "240px" : "0px", 
      backgroundColor: "#0f172a", 
      color: "white", 
      display: "flex", 
      flexDirection: "column", 
      padding: isSidebarOpen ? "20px 15px" : "20px 0", 
      transition: "width 0.3s ease-in-out",
      overflow: "hidden",
      whiteSpace: "nowrap",
      borderRight: "1px solid #1e293b"
    },
    logoArea: { display: "flex", flexDirection: "column", gap: "5px", padding: "0 10px 25px 10px", borderBottom: "1px solid #1e293b", marginBottom: "20px" },
    navItem: { padding: "12px 15px", margin: "4px 0", borderRadius: "8px", cursor: "pointer", display: "flex", alignItems: "center", gap: "12px", color: "#94a3b8", textDecoration: "none", transition: "all 0.2s", fontSize: "14px", fontWeight: "500" },
    navItemActive: { padding: "12px 15px", margin: "4px 0", borderRadius: "8px", cursor: "pointer", display: "flex", alignItems: "center", gap: "12px", color: "white", backgroundColor: "#1e293b", textDecoration: "none", fontSize: "14px", fontWeight: "600" },
    mainContent: { flex: 1, padding: "30px", overflowY: "auto", backgroundColor: "#f4fdf8" },
    topHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "25px" },
    modalOverlay: { position: "fixed", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 10000 },
    modalBox: { backgroundColor: "white", padding: "30px", borderRadius: "12px", width: "350px", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.2)" }
  };

  const getLinkStyle = (path) => location.pathname === path ? styles.navItemActive : styles.navItem;

  return (
    <div style={styles.appContainer}>
      <div style={styles.sidebar}>
        <div style={styles.logoArea}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ backgroundColor: "#3b82f6", padding: "6px", borderRadius: "8px", display: "flex", justifyContent: "center", alignItems: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </div>
            <h2 style={{ margin: 0, fontSize: "18px", letterSpacing: "0.5px", fontWeight: "700" }}>SmartWaste</h2>
          </div>
          <p style={{ margin: 0, fontSize: "11px", color: "#64748b", letterSpacing: "0.5px" }}>Civic Operations Platform</p>
        </div>

        <Link to="/dashboard" style={getLinkStyle("/dashboard")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
          Dashboard
        </Link>
        <Link to="/points" style={getLinkStyle("/points")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          Collection Points
        </Link>
        <Link to="/teams" style={getLinkStyle("/teams")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
          Teams
        </Link>
        <Link to="/schedules" style={getLinkStyle("/schedules")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
          Schedules
        </Link>
        <Link to="/reports" style={getLinkStyle("/reports")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
          Reports
        </Link>
        <Link to="/about" style={getLinkStyle("/about")}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
          About Us
        </Link>
      </div>

      <div style={styles.mainContent}>
        <div style={styles.topHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              style={{ background: "white", border: "1px solid #e2e8f0", borderRadius: "8px", cursor: "pointer", display: "flex", alignItems: "center", color: "#0f172a", padding: "8px", boxShadow: "0 1px 2px rgba(0,0,0,0.05)" }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
            <h1 style={{ margin: 0, color: "#0f172a", fontSize: "20px", fontWeight: "700" }}>
              {localStorage.getItem("role") === "admin" ? "Admin Dashboard" : "Supervisor Dashboard"}
            </h1>
          </div>
          
          <div style={{ display: "flex", gap: "10px" }}>
            <button onClick={() => setShowPasswordModal(true)} style={{ padding: "8px 16px", backgroundColor: "white", color: "#475569", border: "1px solid #cbd5e1", borderRadius: "8px", cursor: "pointer", fontWeight: "600", fontSize: "13px" }}>
              Security
            </button>
            <button onClick={handleLogout} style={{ padding: "8px 16px", backgroundColor: "#dc2626", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "600", fontSize: "13px" }}>
              Log Out
            </button>
          </div>
        </div>
        
        {children}
      </div>

      {showPasswordModal && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalBox}>
            <h3 style={{ marginTop: 0, color: "#0f172a" }}>Update Password</h3>
            <form onSubmit={handlePasswordChange} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              <input type="password" placeholder="Current Password" required value={oldPassword} onChange={e => setOldPassword(e.target.value)} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <input type="password" placeholder="New Password" required value={newPassword} onChange={e => setNewPassword(e.target.value)} style={{ padding: "10px", borderRadius: "6px", border: "1px solid #cbd5e1" }} />
              <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
                <button type="submit" style={{ flex: 1, padding: "10px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>Save</button>
                <button type="button" onClick={() => setShowPasswordModal(false)} style={{ flex: 1, padding: "10px", backgroundColor: "#f1f5f9", color: "#0f172a", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" }}>Cancel</button>
              </div>
            </form>
            {passMessage && <p style={{ textAlign: "center", color: passMessage.includes("success") ? "#166534" : "#dc2626", fontWeight: "bold", marginBottom: 0 }}>{passMessage}</p>}
          </div>
        </div>
      )}
    </div>
  );
}