import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

const greenIcon = new L.Icon({
  iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

const redIcon = new L.Icon({
  iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});

function MapController({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo(center, 14, { duration: 1.5 });
    }
  }, [center, map]);
  return null;
}

export default function CitizenMap() {
  const navigate = useNavigate();
  const [points, setPoints] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [mapCenter, setMapCenter] = useState([0.3476, 32.5825]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDistrict, setFilterDistrict] = useState("All");
  const [activeTab, setActiveTab] = useState("Active");

  const [showForm, setShowForm] = useState(null);
  const [formData, setFormData] = useState({ reporter_name: "", issue_type: "", description: "", is_anonymous: false });

  const fetchData = () => {
    Promise.all([
      fetch("http://localhost:5000/api/points/public").then(res => res.json()),
      fetch("http://localhost:5000/api/reports/public").then(res => res.json())
    ]).then(([pointsData, reportsData]) => {
      setPoints(Array.isArray(pointsData) ? pointsData : []);
      setReports(Array.isArray(reportsData) ? reportsData : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  const handleReport = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/reports/public", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData, point_id: showForm._id })
      });
      if (response.ok) {
        setShowForm(null);
        setFormData({ reporter_name: "", issue_type: "", description: "", is_anonymous: false });
        fetchData();
      }
    } catch (err) { console.error(err); }
  };

  const handleUpvote = async (reportId) => {
    await fetch(`http://localhost:5000/api/reports/public/${reportId}/upvote`, { method: "PATCH" });
    fetchData();
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  if (loading) return <div style={{ padding: "20px" }}>Loading...</div>;

  const filteredReports = reports.filter(r => {
    const point = points.find(p => p._id === r.point_id);
    
    if (activeTab === "Active" && r.status === "Resolved") return false;
    if (activeTab === "Resolved" && r.status !== "Resolved") return false;
    if (filterDistrict !== "All" && (!point || point.district !== filterDistrict)) return false;
    if (searchTerm && !r.issue_type.toLowerCase().includes(searchTerm.toLowerCase()) && !r.description?.toLowerCase().includes(searchTerm.toLowerCase())) return false;

    return true;
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh", backgroundColor: "#f4fdf8", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      
      {/* TOP NAVIGATION BAR */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "15px 30px", backgroundColor: "#065f46", color: "white", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)", zIndex: 1000 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          <h1 style={{ margin: 0, fontSize: "22px", fontWeight: "800", letterSpacing: "0.5px" }}>SmartWaste</h1>
        </div>
        
        <div style={{ display: "flex", gap: "25px", alignItems: "center" }}>
          <span onClick={() => navigate("/citizenHome")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Home</span>
          <span style={{ cursor: "pointer", fontWeight: "600", color: "#22c55e", borderBottom: "2px solid #22c55e", paddingBottom: "4px" }}>Live Map</span>
          <span onClick={() => navigate("/about")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>About Us</span>
          <span onClick={() => navigate("/contact")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Contact</span>
        </div>

        <div>
          <button onClick={handleLogout} style={{ padding: "8px 20px", backgroundColor: "transparent", color: "white", border: "1px solid #22c55e", borderRadius: "20px", cursor: "pointer", fontWeight: "bold" }}>Log Out</button>
        </div>
      </div>

      {/* MAIN CONTENT - WITH MAX WIDTH AND PADDING */}
      <div style={{ flex: 1, padding: "40px", maxWidth: "1400px", margin: "0 auto", width: "100%", display: "flex", flexDirection: "column", gap: "30px" }}>
        
        <div>
          <h1 style={{ margin: "0 0 10px 0", fontSize: "32px", fontWeight: "900", color: "#064e3b" }}>Live Map</h1>
          <p style={{ margin: 0, fontSize: "16px", color: "#64748b" }}>View the status of collection points across the city and report issues.</p>
        </div>

        {/* LAYOUT FOR MAP AND SIDEBAR */}
        <div style={{ display: "flex", gap: "30px", height: "600px" }}>
          
          {/* SIDEBAR */}
          <div style={{ width: "350px", backgroundColor: "#ffffff", borderRadius: "16px", border: "1px solid #e2e8f0", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
            
            <div style={{ display: "flex", borderBottom: "1px solid #e2e8f0", backgroundColor: "#f8fafc" }}>
              <button onClick={() => setActiveTab("Active")} style={{ flex: 1, padding: "15px", border: "none", backgroundColor: activeTab === "Active" ? "#ffffff" : "transparent", color: activeTab === "Active" ? "#065f46" : "#64748b", fontWeight: "700", borderBottom: activeTab === "Active" ? "3px solid #22c55e" : "3px solid transparent", cursor: "pointer" }}>Active</button>
              <button onClick={() => setActiveTab("Resolved")} style={{ flex: 1, padding: "15px", border: "none", backgroundColor: activeTab === "Resolved" ? "#ffffff" : "transparent", color: activeTab === "Resolved" ? "#065f46" : "#64748b", fontWeight: "700", borderBottom: activeTab === "Resolved" ? "3px solid #22c55e" : "3px solid transparent", cursor: "pointer" }}>Resolved</button>
            </div>

            <div style={{ padding: "15px", borderBottom: "1px solid #e2e8f0", display: "flex", flexDirection: "column", gap: "10px" }}>
              <input type="text" placeholder="Search issues..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ padding: "10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "14px", backgroundColor: "#f8fafc" }} />
              <select value={filterDistrict} onChange={(e) => setFilterDistrict(e.target.value)} style={{ padding: "10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "14px", backgroundColor: "#f8fafc" }}>
                <option value="All">All Districts</option>
                <option value="Kampala">Kampala</option>
                <option value="Wakiso">Wakiso</option>
                <option value="Mukono">Mukono</option>
                <option value="Jinja">Jinja</option>
              </select>
            </div>

            <div style={{ flex: 1, overflowY: "auto", padding: "15px", display: "flex", flexDirection: "column", gap: "15px", backgroundColor: "#f8fafc" }}>
              {filteredReports.map(r => {
                const point = points.find(p => p._id === r.point_id);
                let borderColor = "#22c55e"; 
                if (r.priority === "High") borderColor = "#dc2626";
                if (r.priority === "Medium") borderColor = "#f59e0b";

                return (
                  <div key={r._id} style={{ backgroundColor: "white", padding: "15px", borderRadius: "10px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", borderLeft: `4px solid ${borderColor}`, display: "flex", flexDirection: "column", gap: "8px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <strong style={{ fontSize: "14px", color: "#0f172a" }}>{r.issue_type}</strong>
                      <span style={{ fontSize: "10px", fontWeight: "700", padding: "3px 6px", borderRadius: "12px", backgroundColor: r.status === "Resolved" ? "#dcfce7" : "#fef3c7", color: r.status === "Resolved" ? "#166534" : "#92400e" }}>{r.status}</span>
                    </div>
                    <p style={{ margin: 0, fontSize: "12px", color: "#475569" }}>Location: {point ? point.name : "Unknown"}</p>
                    
                    <div style={{ display: "flex", gap: "8px", marginTop: "5px" }}>
                      {r.status !== "Resolved" && (
                        <button onClick={() => handleUpvote(r._id)} style={{ flex: 1, padding: "6px", backgroundColor: "#f0fdf4", color: "#166534", border: "1px solid #bbf7d0", borderRadius: "6px", cursor: "pointer", fontSize: "12px", fontWeight: "700" }}>Me Too ({r.upvotes || 0})</button>
                      )}
                      <button onClick={() => { if (point && point.location) setMapCenter([point.location.coordinates[1], point.location.coordinates[0]]); }} style={{ flex: 1, padding: "6px", backgroundColor: "#065f46", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "12px", fontWeight: "700" }}>View</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* MAP AREA */}
          <div style={{ flex: 1, position: "relative", borderRadius: "16px", overflow: "hidden", border: "1px solid #e2e8f0", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <MapContainer center={mapCenter} zoom={11} style={{ height: "100%", width: "100%" }}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <MapController center={mapCenter} />
              
              {points.map((point) => {
                if (!point.location || !point.location.coordinates) return null;
                const position = [point.location.coordinates[1], point.location.coordinates[0]];
                const pointReports = reports.filter(r => r.point_id === point._id && r.status !== "Resolved");
                
                const isFull = point.current_status === "Full" || point.current_status === "Overflowing";
                const icon = isFull ? redIcon : greenIcon;

                return (
                  <Marker key={point._id} position={position} icon={icon}>
                    <Popup>
                      <div style={{ fontFamily: "'Segoe UI', sans-serif", minWidth: "200px", padding: "5px" }}>
                        <h3 style={{ margin: "0 0 5px 0", fontSize: "15px", color: "#064e3b" }}>{point.name}</h3>
                        <span style={{ display: "inline-block", padding: "3px 8px", borderRadius: "12px", fontSize: "10px", fontWeight: "bold", backgroundColor: isFull ? "#fee2e2" : "#dcfce7", color: isFull ? "#991b1b" : "#166534", marginBottom: "8px" }}>Status: {point.current_status}</span>
                        
                        {pointReports.length > 0 && <hr style={{ border: "0", borderTop: "1px solid #e2e8f0", margin: "8px 0" }} />}
                        
                        {pointReports.map(r => (
                          <div key={r._id} style={{ marginBottom: "8px", backgroundColor: "#f8fafc", padding: "6px", borderRadius: "6px" }}>
                            <strong style={{ fontSize: "12px", color: "#1e293b" }}>{r.issue_type}</strong><br />
                            <span style={{ fontSize: "11px", color: "#64748b" }}>{r.is_anonymous ? "Anonymous" : r.reporter_name}</span>
                          </div>
                        ))}
                        
                        <hr style={{ border: "0", borderTop: "1px solid #e2e8f0", margin: "8px 0" }} />
                        <button onClick={() => setShowForm(point)} style={{ padding: "8px", backgroundColor: "#22c55e", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", width: "100%", fontWeight: "bold", fontSize: "12px" }}>Report Issue</button>
                      </div>
                    </Popup>
                  </Marker>
                );
              })}
            </MapContainer>
          </div>
        </div>
      </div>

      {/* REPORT FORM MODAL */}
      {showForm && (
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(6, 78, 59, 0.7)", backdropFilter: "blur(4px)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 2000 }}>
          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", width: "400px", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.2)" }}>
            <h3 style={{ margin: "0 0 5px 0", fontSize: "20px", color: "#064e3b" }}>Report Issue</h3>
            <p style={{ margin: "0 0 20px 0", fontSize: "13px", color: "#64748b" }}>Location: {showForm.name}</p>
            
            <form onSubmit={handleReport} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "10px", cursor: "pointer", fontSize: "13px", color: "#1e293b", fontWeight: "500" }}>
                <input type="checkbox" checked={formData.is_anonymous} onChange={(e) => setFormData({...formData, is_anonymous: e.target.checked})} style={{ width: "16px", height: "16px", accentColor: "#22c55e" }} />
                Submit Anonymously
              </label>

              {!formData.is_anonymous && (
                <input required placeholder="Your Name" value={formData.reporter_name} onChange={(e) => setFormData({...formData, reporter_name: e.target.value})} style={{ padding: "10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "13px" }} />
              )}

              <input required placeholder="Issue Type" value={formData.issue_type} onChange={(e) => setFormData({...formData, issue_type: e.target.value})} style={{ padding: "10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "13px" }} />
              <textarea placeholder="Details (optional)" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} style={{ padding: "10px", borderRadius: "8px", border: "1px solid #cbd5e1", fontSize: "13px", minHeight: "70px" }} />

              <button type="submit" style={{ padding: "12px", backgroundColor: "#22c55e", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", fontSize: "14px", marginTop: "5px" }}>Submit Report</button>
              <button type="button" onClick={() => setShowForm(null)} style={{ padding: "12px", backgroundColor: "#f1f5f9", color: "#475569", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", fontSize: "14px" }}>Cancel</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}