import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Contact() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setStatus("Sending message...");
    // Backend integration will go here
    setTimeout(() => {
      setStatus("Message sent successfully! We will get back to you soon.");
      setFormData({ name: "", email: "", subject: "", message: "" });
    }, 1500);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh", backgroundColor: "#f4fdf8", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      
      {/* TOP NAVIGATION BAR */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "15px 30px", backgroundColor: "#065f46", color: "white", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          <h1 style={{ margin: 0, fontSize: "22px", fontWeight: "800", letterSpacing: "0.5px" }}>SmartWaste</h1>
        </div>
        
        <div style={{ display: "flex", gap: "25px", alignItems: "center" }}>
          <span onClick={() => navigate("/citizenHome")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Home</span>
          <span onClick={() => navigate("/citizen")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Live Map</span>
          <span onClick={() => navigate("/about")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>About Us</span>
          <span style={{ cursor: "pointer", fontWeight: "600", color: "#22c55e", borderBottom: "2px solid #22c55e", paddingBottom: "4px" }}>Contact</span>
        </div>

        <div>
          <button onClick={handleLogout} style={{ padding: "8px 20px", backgroundColor: "transparent", color: "white", border: "1px solid #22c55e", borderRadius: "20px", cursor: "pointer", fontWeight: "bold" }}>Log Out</button>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex: 1, padding: "60px 30px", display: "flex", justifyContent: "center", alignItems: "center" }}>
        <div style={{ backgroundColor: "white", borderRadius: "24px", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)", display: "flex", maxWidth: "1000px", width: "100%", overflow: "hidden" }}>
          
          {/* LEFT SIDE - INFO */}
          <div style={{ flex: 1, backgroundColor: "#064e3b", padding: "50px", color: "white", display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "32px", fontWeight: "900" }}>Get in Touch</h2>
            <p style={{ margin: "0 0 30px 0", color: "#dcfce7", fontSize: "15px", lineHeight: "1.6" }}>Need a premium home collection? Have a question about our services? Reach out to us directly.</p>
            
            <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
              
              {/* EMAIL */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ backgroundColor: "rgba(34, 197, 94, 0.2)", padding: "8px", borderRadius: "50%" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                </div>
                <span style={{ fontSize: "14px" }}>gregoryrugaramaaboveonly@gmail.com</span>
              </div>

              {/* PHONE */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ backgroundColor: "rgba(34, 197, 94, 0.2)", padding: "8px", borderRadius: "50%" }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                </div>
                <span style={{ fontSize: "14px" }}>+256 763567071</span>
              </div>

            </div>
          </div>

          {/* RIGHT SIDE - FORM */}
          <div style={{ flex: 1, padding: "50px" }}>
            <h2 style={{ margin: "0 0 20px 0", fontSize: "24px", color: "#0f172a" }}>Send a Message</h2>
            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <input type="text" placeholder="Your Name" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} style={{ padding: "12px", borderRadius: "8px", border: "1px solid #cbd5e1" }} />
              <input type="email" placeholder="Your Email" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} style={{ padding: "12px", borderRadius: "8px", border: "1px solid #cbd5e1" }} />
              <input type="text" placeholder="Subject" required value={formData.subject} onChange={(e) => setFormData({...formData, subject: e.target.value})} style={{ padding: "12px", borderRadius: "8px", border: "1px solid #cbd5e1" }} />
              <textarea placeholder="Your Message" required value={formData.message} onChange={(e) => setFormData({...formData, message: e.target.value})} style={{ padding: "12px", borderRadius: "8px", border: "1px solid #cbd5e1", minHeight: "120px" }} />
              
              <button type="submit" style={{ padding: "14px", backgroundColor: "#16a34a", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", fontSize: "16px" }}>Send Message</button>
              
              {status && <p style={{ textAlign: "center", color: status.includes("success") ? "#166534" : "#dc2626", fontWeight: "bold", fontSize: "14px" }}>{status}</p>}
            </form>
          </div>

        </div>
      </div>
    </div>
  );
}