import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function CitizenHome() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ totalReports: 0, resolvedReports: 0 });
  const userName = localStorage.getItem("name") || "Citizen";
  const role = localStorage.getItem("role");

  useEffect(() => {
    fetch("http://localhost:5000/api/reports/public")
      .then(res => res.json())
      .then(data => {
        setStats({
          totalReports: data.length,
          resolvedReports: data.filter(r => r.status === "Resolved").length
        });
      }).catch(() => {});
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh", backgroundColor: "#f4fdf8", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      
      {/* TOP NAVIGATION BAR */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "15px 40px", backgroundColor: "#065f46", color: "white", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          <h1 style={{ margin: 0, fontSize: "22px", fontWeight: "800", letterSpacing: "0.5px" }}>SmartWaste</h1>
        </div>
        
        <div style={{ display: "flex", gap: "30px", alignItems: "center" }}>
          
          {/* BACK TO DASHBOARD BUTTON (Admin/Supervisor only) */}
          {(role === "admin" || role === "dispatcher") && (
            <button 
              onClick={() => navigate("/dashboard")} 
              style={{ padding: "8px 16px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: "bold", display: "flex", alignItems: "center", gap: "8px" }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
              Back to Dashboard
            </button>
          )}

          <span style={{ cursor: "pointer", fontWeight: "600", color: "#22c55e", borderBottom: "2px solid #22c55e", paddingBottom: "4px" }}>Home</span>
          <span onClick={() => navigate("/citizen")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Live Map</span>
          <span onClick={() => navigate("/about")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>About Us</span>
          <span onClick={() => navigate("/contact")} style={{ cursor: "pointer", fontWeight: "500", color: "#dcfce7" }}>Contact</span>
        </div>

        <div>
          <button onClick={handleLogout} style={{ padding: "8px 20px", backgroundColor: "transparent", color: "white", border: "1px solid #22c55e", borderRadius: "20px", cursor: "pointer", fontWeight: "bold" }}>Log Out</button>
        </div>
      </div>

      {/* MAIN CONTENT CONTAINER */}
      <div style={{ flex: 1, maxWidth: "1200px", margin: "0 auto", width: "100%", padding: "40px" }}>
        
        {/* THE HERO SECTION */}
        <div style={{ 
          backgroundColor: "#e8f5e9", 
          borderRadius: "24px", 
          padding: "60px 50px", 
          display: "flex", 
          alignItems: "center", 
          justifyContent: "space-between",
          border: "1px solid #c8e6c9",
          boxShadow: "0 20px 25px -5px rgba(0,0,0,0.05)"
        }}>
          <div style={{ maxWidth: "500px" }}>
            <h1 style={{ margin: 0, fontSize: "80px", fontWeight: "900", color: "#064e3b", lineHeight: "0.9", letterSpacing: "-2px" }}>
              RECYCLE
            </h1>
            <p style={{ margin: "20px 0 30px 0", fontSize: "20px", color: "#065f46", fontWeight: "500", lineHeight: "1.4", maxWidth: "400px" }}>
              Promoting sustainable waste management practices for a cleaner, greener city.
            </p>
            <button 
              onClick={() => navigate("/citizen")} 
              style={{ padding: "14px 28px", backgroundColor: "#065f46", color: "white", border: "none", borderRadius: "30px", fontSize: "16px", fontWeight: "bold", cursor: "pointer", display: "flex", alignItems: "center", gap: "10px" }}
            >
              LEARN MORE
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </button>
          </div>

          <div style={{ position: "relative", width: "400px", height: "400px", display: "flex", justifyContent: "center", alignItems: "center" }}>
            <div style={{ 
              position: "absolute", 
              backgroundColor: "#16a34a", 
              borderRadius: "50%", 
              width: "250px", 
              height: "250px", 
              display: "flex", 
              justifyContent: "center", 
              alignItems: "center",
              boxShadow: "0 25px 50px -12px rgba(22, 163, 74, 0.5)",
              zIndex: 2
            }}>
              <svg width="150" height="150" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            </div>
            
            <div style={{ 
              position: "absolute", 
              right: "0", 
              backgroundColor: "#0f172a", 
              width: "180px", 
              height: "340px", 
              borderRadius: "30px", 
              border: "8px solid #064e3b",
              zIndex: 1,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              boxShadow: "20px 20px 0px 0px rgba(6, 78, 59, 0.1)"
            }}>
              <span style={{ color: "#22c55e", fontSize: "12px", fontWeight: "bold", textAlign: "center" }}>SmartWaste<br/>App</span>
            </div>
          </div>
        </div>

        {/* THE STATS BAR */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px", marginTop: "30px" }}>
          
          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", display: "flex", alignItems: "center", gap: "20px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <div style={{ backgroundColor: "#dcfce7", padding: "15px", borderRadius: "12px" }}>
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path></svg>
            </div>
            <div>
              <h3 style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#0f172a" }}>2.01B Tonnes</h3>
              <p style={{ margin: 0, fontSize: "13px", color: "#64748b" }}>Global waste generated yearly.</p>
            </div>
          </div>

          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", display: "flex", alignItems: "center", gap: "20px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <div style={{ backgroundColor: "#dcfce7", padding: "15px", borderRadius: "12px" }}>
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
            </div>
            <div>
              <h3 style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#0f172a" }}>{stats.totalReports} Reports</h3>
              <p style={{ margin: 0, fontSize: "13px", color: "#64748b" }}>Issues reported in your city.</p>
            </div>
          </div>

          <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "16px", display: "flex", alignItems: "center", gap: "20px", boxShadow: "0 4px 6px -1px rgba(0,0,0,0.05)" }}>
            <div style={{ backgroundColor: "#dcfce7", padding: "15px", borderRadius: "12px" }}>
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
            </div>
            <div>
              <h3 style={{ margin: "0 0 5px 0", fontSize: "16px", color: "#0f172a" }}>{stats.resolvedReports} Resolved</h3>
              <p style={{ margin: 0, fontSize: "13px", color: "#64748b" }}>Issues successfully cleared.</p>
            </div>
          </div>

        </div>

        {/* FOOTER */}
        <div style={{ textAlign: "center", padding: "40px 0 20px 0", borderTop: "1px solid #e2e8f0", marginTop: "40px" }}>
          <h2 style={{ margin: 0, fontSize: "20px", fontWeight: "900", color: "#064e3b", letterSpacing: "1px" }}>SMART<span style={{ color: "#16a34a" }}>WASTE</span></h2>
          <p style={{ margin: "10px 0 0 0", fontSize: "12px", color: "#94a3b8" }}>© 2026 SmartWaste Civic Operations. All rights reserved.</p>
        </div>

      </div>
    </div>
  );
}