import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Login from "./Login";
import Register from "./Register";
import Dashboard from "./Dashboard";
import Points from "./Points";
import Teams from "./Teams";
import Schedules from "./Schedules";
import Reports from "./Reports";
import CitizenMap from "./CitizenMap";
import About from "./About";
import CitizenAbout from "./CitizenAbout";
import CitizenHome from "./CitizenHome";
import Contact from "./Contact";

function App() {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  return (
    <BrowserRouter>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* Admin/Staff Routes */}
        <Route path="/dashboard" element={token ? <Dashboard /> : <Navigate to="/" />} />
        <Route path="/points" element={token ? <Points /> : <Navigate to="/" />} />
        <Route path="/teams" element={token ? <Teams /> : <Navigate to="/" />} />
        <Route path="/schedules" element={token ? <Schedules /> : <Navigate to="/" />} />
        <Route path="/reports" element={token ? <Reports /> : <Navigate to="/" />} />

        {/* Citizen Routes */}
        <Route path="/citizenHome" element={token ? <CitizenHome /> : <Navigate to="/" />} />
        <Route path="/citizen" element={token ? <CitizenMap /> : <Navigate to="/" />} />
        
        {/* Shared Routes with Role Check for About Page */}
        <Route path="/about" element={token ? (role === "reporter" ? <CitizenAbout /> : <About />) : <Navigate to="/" />} />
        <Route path="/contact" element={token ? <Contact /> : <Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;